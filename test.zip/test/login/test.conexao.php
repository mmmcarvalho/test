 <?php
 /* Require no script contendo a classe */  
 require_once 'conexao.php'; 
 
 /* Variável recebendo instância do objeto PDO */  
 $pdo = Conexao::getInstance();  
 
 if (is_object($pdo)){
	 echo "Conexão ok!!!";
 }
 ?>  