<?php
require "conexao.php";

$nome = 'William';
$email = 'wllfl@ig.com.br';
$senha = password_hash('devwilliam', PASSWORD_DEFAULT);

$nome = 'Maurício Carvalho';
$email = 'mmmcarvalho@yahoo.com.br';
$senha = password_hash('senha', PASSWORD_DEFAULT);

$conexao = conexao::getInstance();
$sql = "truncate tab_usuario";
$stm = $conexao->prepare($sql);
//$stm->execute();
$sql = "INSERT INTO tab_usuario(nome, email, senha, status)VALUES('{$nome}', '{$email}', '{$senha}', 'Ativo')";
$stm = $conexao->prepare($sql);
$stm->execute();

if (isset($_SERVER['HTTP_REFERER'])):
	echo ("<h2>Origem da requisição: {$_SERVER['HTTP_REFERER']}</h2>");
else:
	echo ('<h2>Origem da requisição não autorizada!</h2>');
endif;

echo ("<h2>Teste ok!!!</h2>");