﻿<?php
header ( 'Content-Type: application/json' );

$data = '[
			{"id":"1","text":"A. M JUNIOR MAT. CONSTRUÇÃO"},
			{"id":"2","text":"IRMÃOS TEIXEIRA LTDA"},
			{"id":"3","text":"RD BRASIL"},
			{"id":"4","text":"MEGA APOIO"},
			{"id":"5","text":"GERDAU AÇOS LONGOS S/A"},
			{"id":"6","text":"VIMINAS VIDROS"},
			{"id":"7","text":"JATOBÁ"},
			{"id":"8","text":"REAL PERFIL IND E COM LTDA"},
			{"id":"9","text":"TECNOBOLT LTDA"}
		]';
#echo json_encode($data);
echo $data;