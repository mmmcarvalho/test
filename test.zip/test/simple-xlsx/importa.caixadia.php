<?php 

/* Seta configuração para não dar timeout */
ini_set('max_execution_time','-1');
date_default_timezone_set ( 'UTC' );

/* Require com a classe de importação construída */
require_once ("../../decol/config.ini.php");
require 'ImportaCaixaDia.class.php';

/* Instância conexão PDO com o banco de dados */
$pdo = new PDO("mysql:host={$Conexao ["Servidor"]};dbname={$Conexao ["BancoDados"]}", $Conexao ["Usuario"], $Conexao ["Senha"]); 
//$pdo = new PDO('mysql:host=mysql03.decol.eng.br;dbname=decol2', 'decol2', 'decoleng8117');

/* Instância o objeto importação e passa como parâmetro o caminho da planilha e a conexão PDO */
//$obj = new ImportaCaixaDia('./CAIXADIA-00.12.2016.xlsx', $pdo);
//$obj = new ImportaCaixaDia('./caixas-id-18-28.04.2016.xlsx', $pdo);
$obj = new ImportaCaixaDia('caixa-dia-00.00.0000.importar.xlsx', $pdo);

/* Chama o método que retorna a quantidade de linhas */
echo 'Quantidade de Linhas na Planilha ' , $obj->getQtdeLinhas(), '<br>';

/* Chama o método que retorna a quantidade de colunas */
echo 'Quantidade de Colunas na Planilha ' , $obj->getQtdeColunas(), '<br>';

/* Chama o método que inseri os dados e captura a quantidade linhas importadas */
$linhasImportadas = $obj->insertDados();

/* Chama o método que ler as planilhas importadas */
$Caixa = $obj->getPlanilhas()->rows();

/* Converte das planilhas imprtadas em JSON */
$jsonCaixa = json_encode($Caixa);

/* Imprime a quantidade de linhas importadas */
echo 'Foram importadas ', $linhasImportadas, ' linhas';

/* Imprime a quantidade de linhas importadas */
echo "<h1>Caixa</h1>";
//var_dump($Caixa);

/* Imprime a quantidade de linhas importadas */
echo "<h1>JSON Caixa</h1>";
var_dump($jsonCaixa);
$dataUnixStamp = $obj->getPlanilhas()->unixstamp('40941');
var_dump($dataUnixStamp);
var_dump(date('d/m/Y',$dataUnixStamp));
var_dump(date('T'));

date_default_timezone_set ( 'UTC' );
var_dump(date_default_timezone_get ());
var_dump(date('d/m/Y H:m:s'));
var_dump(date('T'));

date_default_timezone_set ( 'America/Sao_Paulo' );
var_dump(date_default_timezone_get ());
var_dump(date('d/m/Y h:m:s'));
var_dump(date('T'));

date_default_timezone_set ( 'America/Belem' );
var_dump(date_default_timezone_get ());
var_dump(date('d/m/Y h:m:s'));
var_dump(date('T'));

