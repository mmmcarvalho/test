<?php
ini_set ( 'max_execution_time', '-1' );
require_once ("simplexlsx.class.php");
class ImportaCaixaDia {
	
	// Atributo recebe a instância da conexão PDO
	private $conexao = null;
	
	// Atributo recebe uma instância da classe SimpleXLSX
	private $planilha = null;
	
	// Atributo recebe a quantidade de linhas da planilha
	private $linhas = null;
	
	// Atributo recebe a quantidade de colunas da planilha
	private $colunas = null;
	
	// Atributo recebe os registros de uma coluna
	private $registro = null;
	
	/*
	 * Método Construtor da classe
	 * @param $path - Caminho e nome da planilha do Excel xlsx
	 * @param $conexao - Instância da conexão PDO
	 */
	public function __construct($path = null, $conexao = null) {
		if (! empty ( $path ) && file_exists ( $path )) :
			$this->planilha = new SimpleXLSX ( $path );
			list ( $this->colunas, $this->linhas ) = $this->planilha->dimension ();
		 else :
			echo 'Arquivo não encontrado!';
			exit ();
		endif;
		
		if (! empty ( $conexao )) :
			$this->conexao = $conexao;
		 else :
			echo 'Conexão não informada!';
			exit ();
		endif;
	}
	
	/*
	 * Método que retorna o valor do atributo $linhas
	 * @return Valor inteiro contendo a quantidade de linhas na planilha
	 */
	public function getQtdeLinhas() {
		return $this->linhas;
	}
	
	/*
	 * Método que retorna o valor do atributo $colunas
	 * @return Valor inteiro contendo a quantidade de colunas na planilha
	 */
	public function getQtdeColunas() {
		return $this->colunas;
	}
	
	/*
	 * Método que retorna o valor do atributo $colunas
	 * @return Linhas e Colunas na planilha
	 */
	public function getPlanilhas() {
		return $this->planilha;
	}
	
	/*
	 * Método que retorna o valor do atributo $colunas
	 * @return O valor da coluna
	 */
	public function getRegistros() {
		return $this->registro;
	}
	
	/*
	 * Método que verifica se o registro do numero da nota fiscal da planilha já existe na tabela cliente
	 * @param $Numero - Número da nota fiscal que está sendo lido na planilha
	 * @return Valor Booleano TRUE para duplicado e FALSE caso não
	 */
	private function isRegistroDuplicado($numero = null, $data = null) {
		$retorno = false;
		try {
			if (! empty ( $numero )) :
				$sql = 'SELECT ID_NOTAFISCAL, ID_SITUACAO, NF_NUMERO, NF_VENCIMENTO, NF_DATA, DT_PAGAMENTO FROM eng_notafiscal WHERE NF_NUMERO = :numero AND NF_DATA = :data';
				$stm = $this->conexao->prepare ( $sql );
				$stm->bindValue ( ":numero", $numero );
				$stm->bindValue ( ":data"  , $data   );
				$stm->execute ();
				$dados = $stm->fetch(PDO::FETCH_ASSOC);
				
				if (! empty ( $dados )) :
				    //var_dump ( $dados );
					$retorno = true;
				else :
				 	$retorno = false;
					//var_dump ( $dados );
					//var_dump ($stm->errorInfo());
				endif;
			
			endif;
		} catch ( Exception $erro ) {
			echo 'Erro: ' . $erro->getMessage ();
			
			$retorno = false;
		}
		
		return $retorno;
	}
	/*
	 * Método que verificar se o registro já existe na tabela informacada
	 * @param $nomeRegistro - Nome do Registro que está sendo lido na planilha
	 * @return Valor Booleano TRUE para se Existe e FALSE caso não
	 */
	private function isRegistro($nomeRegistro = null, $valorRegistro = null, $nomeTabela = null) {
		$retorno = false;
		
		try {
			if (! empty ( $nomeRegistro )) :
				$sql = "SELECT {$nomeRegistro}, DESCRICAO FROM {$nomeTabela} WHERE UPPER(DESCRICAO) = :descricao OR {$nomeRegistro} = :id";
				$stm = $this->conexao->prepare ( $sql );
				$stm->bindValue ( ":descricao"	, $valorRegistro );
				$stm->bindValue ( ":id"			, $valorRegistro );
				$stm->execute ();
				$dados = $stm->fetch(PDO::FETCH_ASSOC);
				$this->registro = $dados [$nomeRegistro];
				
				//var_dump($nomeRegistro, $valorRegistro, $nomeTabela, $dados[$nomeRegistro], $dados);
				
				if (! empty ( $dados )) :
					$retorno = true;
				 else :
					$retorno = false;
				endif;
			
				
			endif;
		} catch ( Exception $erro ) {
			echo 'Erro: ' . $erro->getMessage ();
			$retorno = false;
		}
		
		return $retorno;
	}
	
	/*
	 * Método para ler os dados da planilha e inserir no banco de dados
	 * @return Valor Inteiro contendo a quantidade de linhas importadas
	 */
	public function insertDados() {
		try {
			$sql = "INSERT INTO eng_notafiscal 
						(ID_OBRA, ID_FORNECEDOR, ID_SITUACAO, ID_FORMASPGTO, 
						 NF_NUMERO, NF_VALOR, NF_VALOR_PAGO, NF_DATA, NF_VENCIMENTO, DT_PAGAMENTO,ISTATUS,IDATA) 
					VALUES(:obra,:fornecedor,:situacao,:formas,:numero,:valor, :pago, :data,:vencimento,:pgto,:istatus,:idata)";
			$stm = $this->conexao->prepare ( $sql );
			
			$linha = 0;
			//var_dump($this->planilha->rows ());
			
			foreach ( $this->planilha->rows () as $chave => $valor ) :
				 
				$numero 	= utf8_decode ( trim( $valor [0] ) );
				$data 		= date ( "d/m/Y", $this->planilha->unixstamp ( $valor [3] ) );
				
				var_dump($valor [3], $data);
				
				if ($chave >= 1 && !$this->isRegistroDuplicado($numero, $data)):		
					
					$obra 			= $this->isRegistro ( "ID_OBRA", trim ( $valor [1] ), "eng_obra" ) ? $this->getRegistros () : 0;
					$valorPago 		= number_format(trim ( $valor [2] ), 2, ',', '.');
					$formaPgto 		= $this->isRegistro ( "ID_FORMASPGTO", trim ( $valor [6] ), "fin_formaspgto" ) ? $this->getRegistros () : 1;
					$vencimento		= $data;
					$pagamento 		= $data;
					$situacao 		= $valor[7];
					$fornecedor 	= $valor[9] ? $valor[9] : 150;
					$istatus 		= 1;
					$idata 			= date ( "Y-m-d h:m:s" );
					
					$stm->bindValue ( ":obra"		, $obra 		);
					$stm->bindValue ( ":fornecedor"	, $fornecedor 	);
					$stm->bindValue ( ":situacao"	, $situacao 	);
					$stm->bindValue ( ":formas"		, $formaPgto 	);
					$stm->bindValue ( ":numero"		, $numero 		);
					$stm->bindValue ( ":valor"		, $valorPago 	);
					$stm->bindValue ( ":pago"		, $valorPago 	);
					$stm->bindValue ( ":data"		, $data 		);
					$stm->bindValue ( ":vencimento"	, $vencimento 	);
					$stm->bindValue ( ":pgto"		, $pagamento 	);
					$stm->bindValue ( ":istatus"	, $istatus 		);
					$stm->bindValue ( ":idata"		, $idata 		);
					$retorno = true;
					//$retorno = $stm->execute ();
					
					if ($retorno == true): 
						$linha ++; 
					endif;
				
				 endif;
			endforeach;
			
			return $linha;
		} catch ( Exception $erro ) {
			echo 'Erro: ' . $erro->getMessage ();
		}
	}
}