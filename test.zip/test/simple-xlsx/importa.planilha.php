<?php 

/* Seta configuração para não dar timeout */
ini_set('max_execution_time','-1');

/* Require com a classe de importação construída */
require 'ImportaPlanilha.class.php';

/* Instância conexão PDO com o banco de dados */
$pdo = new PDO('mysql:host=localhost;dbname=blog', 'root', '');

/* Instância o objeto importação e passa como parâmetro o caminho da planilha e a conexão PDO */
$obj = new ImportaPlanilha('./caixa-dia-00.00.0000.importar.xlsx', $pdo);

/* Chama o método que retorna a quantidade de linhas */
echo 'Quantidade de Linhas na Planilha ' , $obj->getQtdeLinhas(), '<br>';

/* Chama o método que retorna a quantidade de colunas */
echo 'Quantidade de Colunas na Planilha ' , $obj->getQtdeColunas(), '<br>';

/* Chama o método que inseri os dados e captura a quantidade linhas importadas */
$linhasImportadas = $obj->insertDados();

/* Chama o método que ler as planilhas importadas */
$Clientes = $obj->getPlanilhas()->rows(1);
$Usuarios = $obj->getPlanilhas()->rows(2);

/* Converte das planilhas imprtadas em JSON */
$jsonClientes = json_encode($Clientes);
$jsonUsuarios = json_encode($Usuarios);

/* Imprime a quantidade de linhas importadas */
echo 'Foram importadas ', $linhasImportadas, ' linhas';

/* Imprime a quantidade de linhas importadas */
echo "<h1>Clientes</h1>";
var_dump($Clientes);
echo "<h1>Usuários</h1>";
var_dump($Usuarios);

/* Imprime a quantidade de linhas importadas */
echo "<h1>JSON Clientes</h1>";
var_dump($jsonClientes);
echo "<h1>JSON Usuários</h1>";
var_dump($jsonUsuarios);
