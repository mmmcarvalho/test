select2-json-php-mysql-bootstrap-jquery
=======================================

Select2 + jSon + PHP + MySQL + Bootstrap + jQuery


#Database Connection
https://github.com/Wrenbjor/PHP-PDO-Connection