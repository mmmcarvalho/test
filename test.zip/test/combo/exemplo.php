<?php
header('Content-type: text/json');

$retorno = array();
switch($_POST['montadora'])
{
   case 1: //Fiat
      $retorno = array(
         10 => "Uno",
         11 => "Palio",
         12 => "Siena"
      );
      break;
   case 2: //Ford
      $retorno = array(
         13 => "Escort",
         14 => "Ka",
         15 => "Edge"
      );
      break;
   case 3: //Volkswagen
      $retorno = array(
         16 => "Fusca",
         17 => "Gol",
         18 => "Jetta"
      );
      break;
}
 
echo json_encode($retorno);
?>