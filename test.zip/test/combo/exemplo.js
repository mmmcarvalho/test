$(document).ready(function(){
   $("#montadora").change(function(){
      $.ajax({
         type: "POST",
         url: "exemplo.php",
         data: {montadora: $("#montadora").val()},
         dataType: "json",
         success: function(json){
            var options = "";
            $.each(json, function(key, value){
               options += '<option value="' + key + '">' + value + '</option>';
            });
            $("#veiculo").html(options);
         }
      });
   });
});